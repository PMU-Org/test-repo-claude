delia-red-300x600 — HTML5 banner 300x600
================================================

Source            delia-red-300x600.webm
Frames            30 (8 cols x 4 rows)
Frame rate        15 fps
Animation length  2.00 s x 3 loop(s)
Sprite sheet      sprite.jpg — 2400x2400 px (100% of display size)
Backup image      backup.jpg
Click-through     https://example.com/delia

Files
  index.html      the creative; entry point for the ad server
  sprite.jpg      sprite sheet with every frame
  backup.jpg      static backup image (single frame)

Notes
  - index.html declares <meta name="ad.size"> and a global clickTag variable,
    so Google Ads, Display & Video 360 and Campaign Manager pick up both the
    dimensions and the exit URL automatically.
  - The animation stops on its last frame after the loop budget is spent and
    pauses while the tab is hidden.
  - Keep index.html and the sprite in the same folder; upload the ZIP as-is.

Generated with WebM -> HTML5 Banner Converter.
