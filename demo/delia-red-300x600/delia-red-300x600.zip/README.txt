delia-red-300x600 — HTML5 banner 300x600
================================================

Source            delia-red-300x600.webm
Frames            24 (7 cols x 4 rows)
Frame rate        12 fps
Animation length  2.00 s x 3 loop(s)
Sprite sheet      embedded — 2100x2400 px (100% of display size)
Packaging         single file, sprite embedded as a data: URI
Backup image      backup.jpg — downloaded separately, not in this ZIP
Click-through     https://example.com/delia

Files
  index.html      the complete creative; the sprite sheet is embedded in it,
                  so this one file is the whole banner

Notes
  - index.html declares <meta name="ad.size"> and a global clickTag variable,
    so Google Ads, Display & Video 360 and Campaign Manager pick up both the
    dimensions and the exit URL automatically.
  - The animation stops on its last frame after the loop budget is spent and
    pauses while the tab is hidden.
  - Everything is in index.html, so the banner cannot be broken by a
    partial extraction. Upload the ZIP as-is.

Generated with WebM -> HTML5 Banner Converter.
